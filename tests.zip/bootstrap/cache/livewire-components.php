<?php return array (
  'create-design' => 'App\\Http\\Livewire\\CreateDesign',
  'design-quote' => 'App\\Http\\Livewire\\DesignQuote',
  'product' => 'App\\Http\\Livewire\\Product',
);