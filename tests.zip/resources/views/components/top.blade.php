<section class="uppercase bg-gray-300 text-center py-2">
    <p class="px-4 font-semibold flex items-center justify-center"><span class="mx-2 -translate-y-[1px]">🎁</span> EASTER SALE | UP TO 20% OFF SITEWIDE <span class="mx-2 -translate-y-[1px]">🎁</span></p>
</section>