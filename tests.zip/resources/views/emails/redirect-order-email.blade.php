<x-mail::message>
# Order placed email from VitalNeon  
{{ $data }}
Best Regards,  
<b>VitalNeon Support</b>
</x-mail::message>
