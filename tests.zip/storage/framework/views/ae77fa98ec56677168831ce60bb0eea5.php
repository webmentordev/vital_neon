<nav class="w-full py-2 sticky top-0 left-0 z-50 bg-dark text-white bg-opacity-80 backdrop-blur-lg">
    <div class="flex items-center justify-between max-w-[90%] m-auto w-full px-2">
        <a href="<?php echo e(route('home')); ?>" class="text-3xl font-semibold py-1"><img src="<?php echo e(asset('assets/neon_tranp_white.png')); ?>" width="150" alt="Vital Neon"></a>
        <ul class="flex items-center uppercase 1090px:hidden">
            <a class="mx-4" href="<?php echo e(route('home')); ?>">Home</a>
            <a class="mx-4" href="<?php echo e(route('create-design')); ?>">Design Your Own</a>
            <a class="mx-4" href="<?php echo e(route('upload-design')); ?>">Upload Design</a>
            <a class="mx-4" href="<?php echo e(route('products')); ?>">Products</a>
            
            <?php if(auth()->guard()->check()): ?>
                <a class="mx-4" href="<?php echo e(route('design.quote')); ?>">Quote</a>
            <?php endif; ?>

            <div class="mx-4 relative group">
                <span class="category flex items-center">Categories <img src="https://api.iconify.design/ic:outline-arrow-drop-down.svg?color=%23ffffff" width="28" alt="Carret Down Logo"></span>
                <div class="hidden group-hover:block absolute top-7 max-w-[200px] w-full p-2 rounded-lg bg-dark bg-opacity-80 backdrop-blur-lg border border-white/10 text-gray-700">
                    <ul class="flex flex-col w-full text-white text-center">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($loop->last): ?>
                                <a class="text-[15px] hover:font-semibold container" href="<?php echo e(route('category.search', $item->slug)); ?>"><?php echo e($item->name); ?></a>
                            <?php else: ?>
                                <a class="text-[15px] hover:font-semibold container border-b-4 border-white/10" href="<?php echo e(route('category.search', $item->slug)); ?>"><?php echo e($item->name); ?></a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <a class="px-5 border-r border-gray-600" href="<?php echo e(route('support')); ?>">Support</a>
            <a href="https://wa.me/16476165799" class="ml-5"><img src="https://api.iconify.design/logos:whatsapp-icon.svg?color=%23ffd402" width="36" alt="Whatsapp Icon"></a>
        </ul>
        <div class="hidden 1090px:block" x-data="{open: false}">
            <ul x-on:click="open = true">
                <li class="bg-white my-2 h-[2px] w-[80px]"></li>
                <li class="bg-white my-2 h-[2px] w-[80px]"></li>
                <li class="bg-white my-2 h-[2px] w-[80px]"></li>
            </ul>
            <div class="fixed top-0 left-0 w-full h-screen bg-dark backdrop-blur-lg flex justify-center items-center z-50" x-show="open" x-on:click.self="open = !open">
                <ul class="text-center flex flex-col">
                    <a class="text-2xl mb-3" href="<?php echo e(route('home')); ?>">Home</a>
                    <a class="text-2xl mb-3" href="<?php echo e(route('create-design')); ?>">Design Your Own</a>
                    <a class="text-2xl mb-3" href="<?php echo e(route('upload-design')); ?>">Upload Design</a>
                    <a class="text-2xl mb-3" href="<?php echo e(route('products')); ?>">Products</a>
                    <a class="text-2xl mb-3" href="<?php echo e(route('support')); ?>">Support</a>
                    <?php if(auth()->guard()->check()): ?>   
                        <a class="text-2xl mb-3" href="<?php echo e(route('design.quote')); ?>">Quote</a>
                    <?php endif; ?>
                    <div class="mx-4 relative" x-data="{toggle: false}">
                        <span class="flex items-center category text-3xl p-3 bg-light rounded-lg" x-on:click="toggle = !toggle">Categories <img src="https://api.iconify.design/ic:outline-arrow-drop-down.svg?color=%23ffffff" width="28" alt="Carret Down Logo"></span>
                        <div class="flex flex-col" x-show="toggle">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="text-2xl" href="<?php echo e(route('category.search', $item->slug)); ?>"><?php echo e($item->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <a href="https://wa.me/16476165799" class="text-2xl mb-3 m-auto"><img src="https://api.iconify.design/logos:whatsapp-icon.svg?color=%23ffd402" width="36" alt="Whatsapp Icon"></a>
                </ul>
            </div>
        </div>
    </div>
</nav><?php /**PATH E:\Web Development\vital_neon\resources\views/components/navbar.blade.php ENDPATH**/ ?>