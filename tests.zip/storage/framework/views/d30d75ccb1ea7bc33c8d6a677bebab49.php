<section class="w-full py-[80px]">
    <div class="flex <?php if($direction): ?> flex-col <?php endif; ?> text-white max-w-[1360px] m-auto 890px:flex 890px:flex-col bg-dark p-6 mb-6">
        <div wire:loading wire:target="checkout" class="fixed left-[45%] 575px:left-0 bottom-3">
            <div class="flex items-center bg-black text-white p-6 rounded-lg"><img src="https://api.iconify.design/svg-spinners:ring-resize.svg?color=%23ffffff" alt="Loading Icon"> <span class="ml-2">Processing...</span></div>
        </div>
        <div class="bg-cover bg-center relative rounded-lg flex justify-center items-center h-[980px] w-full 890px:min-h-[800px]" style="background-image: url(<?php echo e($backgroundImage); ?>)" id="backDiv">
            <span class="fixed bg-main rounded-lg p-3 bottom-3 right-3 text-gray-800 text-4xl font-semibold z-50"><span class="text-2xl">$</span><?php echo e($total_price); ?></span>
            
            <div wire:click="$set('dark_mode', <?php echo e(!$dark_mode); ?>)" class=" <?php if(!$dark_mode): ?> bg-white <?php else: ?> bg-gray-800 <?php endif; ?> p-3 rounded-lg absolute top-2 left-2">
                <?php if(!$dark_mode): ?>
                    <img src="https://api.iconify.design/mdi:lightbulb-on.svg?color=%23e4aa0c" width="35" alt="Sun Image">
                <?php else: ?>
                    <img src="https://api.iconify.design/mdi:lightbulb-on.svg?color=%23ffffff" width="35" alt="Moon Image">
                <?php endif; ?>
            </div>

            <div wire:click="$set('direction', <?php echo e(!$direction); ?>)" class="bg-white p-[14px] rounded-lg absolute top-[10px] left-[72px]">
                <img src="https://api.iconify.design/akar-icons:full-screen.svg?color=%23e4aa0c" width="30" alt="Sun Image">
            </div>

            <div class="absolute top-2 right-2">
                <div class="flex items-center">
                    <div class="flex mr-1">
                        <div class="bg-gray-800 p-1 rounded-lg mb-1 cursor-pointer h-fit mr-1" wire:click="$set('size', <?php echo e($this->size + 10); ?>)">
                            <img src="https://api.iconify.design/material-symbols:add-rounded.svg?color=%23ffffff" width="30" alt="">
                        </div>
                        <div class="bg-gray-800 p-1 rounded-lg cursor-pointer h-fit" wire:click="$set('size', <?php echo e($this->size - 10); ?>)">
                            <img src="https://api.iconify.design/ic:outline-remove.svg?color=%23ffffff" width="30" alt="">
                        </div>
                    </div>
                    <div class="flex flex-col">
                        <div class="bg-gray-800 p-1 rounded-lg mb-1 cursor-pointer" wire:click="$set('leading', <?php echo e($this->leading + 10); ?>)">
                            <img src="https://api.iconify.design/ic:outline-keyboard-arrow-up.svg?color=%23ffffff" width="30" alt="">
                        </div>
                        <div class="bg-gray-800 p-1 rounded-lg cursor-pointer" wire:click="$set('leading', <?php echo e($this->leading - 10); ?>)">
                            <img src="https://api.iconify.design/ic:outline-keyboard-arrow-down.svg?color=%23ffffff" width="30" alt="">
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex flex-col <?php echo e($alignment); ?>" id="main-text">
                <span class="text-white <?php echo e($font); ?> font-semibold" 
                style="<?php if(!$dark_mode): ?> text-shadow:
                <?php echo e($color); ?> 0px 0px 5px,
                <?php echo e($color); ?> 0px 0px 10px,
                <?php echo e($color); ?> 0px 0px 20px,
                <?php echo e($color); ?> 0px 0px 30px,
                <?php echo e($color); ?> 0px 0px 40px,
                <?php echo e($color); ?> 0px 0px 55px,
                <?php echo e($color); ?> 0px 0px 75px; <?php endif; ?> font-size: <?php echo e($size); ?>px;"><?php echo e($line1); ?></span>
                <?php if($line2): ?>
                <span class="text-white <?php echo e($font2); ?> font-semibold" 
                style="<?php if(!$dark_mode): ?> text-shadow:
                    <?php echo e($color2); ?> 0px 0px 5px,
                    <?php echo e($color2); ?> 0px 0px 10px,
                    <?php echo e($color2); ?> 0px 0px 20px,
                    <?php echo e($color2); ?> 0px 0px 30px,
                    <?php echo e($color2); ?> 0px 0px 40px,
                    <?php echo e($color2); ?> 0px 0px 55px,
                    <?php echo e($color2); ?> 0px 0px 75px; <?php endif; ?> font-size: <?php echo e($size); ?>px; margin-top: <?php echo e($leading); ?>px"><?php echo e($line2); ?></span>
                <?php endif; ?>
                <?php if($line3): ?>
                    <span class="text-white <?php echo e($font3); ?> font-semibold" 
                    style="<?php if(!$dark_mode): ?> text-shadow:
                    <?php echo e($color3); ?> 0px 0px 5px,
                    <?php echo e($color3); ?> 0px 0px 10px,
                    <?php echo e($color3); ?> 0px 0px 20px,
                    <?php echo e($color3); ?> 0px 0px 30px,
                    <?php echo e($color3); ?> 0px 0px 40px,
                    <?php echo e($color3); ?> 0px 0px 55px,
                    <?php echo e($color3); ?> 0px 0px 75px; <?php endif; ?> font-size: <?php echo e($size); ?>px; margin-top: <?php echo e($leading); ?>px"><?php echo e($line3); ?></span>
                <?php endif; ?>
            </div>

            <div class="flex items-center justify-between absolute w-full bottom-0 p-3 530px:flex-col">
                
                
                <input type="range" id="move" name="move" min="-400" max="400" value="0" class="530px:mb-3 w-[200px] h-[5px] 530px:w-full">
                
                <div class="px-2">
                    <label for="photo" class="flex items-center"><span class="mr-2 text-white font-semibold">Upload Your Own Image</span><img src="https://api.iconify.design/line-md:uploading-loop.svg?color=%23ffffff" width="40" alt="Upload"></label>
                    <input type="file" id="photo" accept="image/*" onchange="loadFile(event)" class="hidden">
                </div>
            </div>
        </div>
        <form wire:submit.prevent="checkout" method="POST" class="bg-light text-sm w-full px-6 py-6 850px:px-0 850px:overflow-y-hidden">
            <div class="flex items-center justify-between 490px:flex-col">
                <h1 class="text-main font-bold text-3xl mb-3">Design Your Neon</h1>
                <div class="flex items-center">
                    <img wire:click="$set('alignment', 'items-center')" src="https://api.iconify.design/material-symbols:format-align-center.svg?color=%23FFFFFF" class="p-2 rounded-lg bg-dark mr-2" alt="Alignment Icon" width="50">
                    <img wire:click="$set('alignment', 'items-start')" src="https://api.iconify.design/ic:baseline-format-align-left.svg?color=%23FFFFFF" class="p-2 rounded-lg bg-dark mr-2" alt="Alignment Icon" width="50">
                    <img wire:click="$set('alignment', 'items-end')" src="https://api.iconify.design/ic:baseline-format-align-right.svg?color=%23FFFFFF" class="p-2 rounded-lg bg-dark" alt="Alignment Icon" width="50">
                </div>
            </div>
            <?php if(session('failed')): ?>
                <p class="text-white p-6 fixed bottom-2 left-2 z-20 rounded-lg bg-red-700 mb-3 border-red-600 border"><?php echo e(session('failed')); ?></p>
            <?php endif; ?>
            <div class="py-2">
                <h2 class="font-bold text-lg">Text Line & Size Options</h2>
                <?php $__errorArgs = ['line_check'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 mb-2"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mt-1">
                    <select wire:model="Select" class="w-full mt-2 bg-dark rounded border focus:border-main focus:ring-4 focus:ring-main-light text-base outline-none text-gray-300 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out mb-3">
                        <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($loop->first): ?>
                                <option value="<?php echo e($line->name); ?>" selected><?php echo e($line->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($line->name); ?>"><?php echo e($line->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            
            <?php if($line_count >= 1): ?>
            <div class="p-6 bg-[#1E1E1E] rounded-lg mb-5">
                <h2 class="font-bold text-lg">Line One Text</h2>
                <?php $__errorArgs = ['line1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 mb-2"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="text" wire:model.debounce.1000ms="line1" placeholder="Text Line One" class="w-full mt-2 bg-dark rounded border focus:border-main focus:ring-4 focus:ring-main-light text-base outline-none text-gray-200 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out mb-3">
                <?php if(session('lineCount1')): ?>
                    <p class="text-red-600 mb-2"><?php echo e(session('lineCount1')); ?></p>
                <?php endif; ?>
                <div class="py-2" x-data="{ open: false }">
                    <h2 class="font-bold mb-2 text-lg">Choose Line-1 Font</h2>
                    <span class="p-6 border border-main bg-dark w-full inline-block rounded-lg text-center font-semibold mb-3 uppercase" x-on:click="open = !open">Open / close</span>
                    <div class="grid grid-cols-2 gap-2 475px:grid-cols-1" x-show="open" x-cloak>
                        <?php $__currentLoopData = $fonts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fonty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="p-3 cursor-pointer rounded-lg text-center border text-lg capitalize <?php echo e($fonty); ?> <?php if($font == $fonty): ?> border-main <?php else: ?> border-white/10 <?php endif; ?>" wire:click="$set('font', '<?php echo e($fonty); ?>')">
                                <?php echo e($fonty); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="py-2">
                    <h2 class="font-bold mb-2 text-lg">Choose a colour</h2>
                    <div class="flex flex-wrap">
                        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div wire:click="$set('color', '<?php echo e($item); ?>')" class="rounded-full m-2" style="<?php if($color == $item): ?> border: 2px <?php echo e($item); ?> solid; <?php endif; ?>">
                                <span class="flex p-2 cursor-pointer rounded-full flex-col border border-white shadow-md" style="background-color: <?php echo e($item); ?>;"></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if($line_count >= 2): ?>
                <div class="p-6 bg-[#1E1E1E] rounded-lg mb-5">
                    <h2 class="font-bold text-lg">Line Two Text</h2>
                    <?php $__errorArgs = ['line2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 mb-2"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="text" wire:model.debounce.1000ms="line2" placeholder="Text Line Two" class="w-full mt-2 bg-dark rounded border focus:border-main focus:ring-4 focus:ring-main-light text-base outline-none text-gray-200 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out mb-3">
                    <?php if(session('lineCount2')): ?>
                        <p class="text-red-600 mb-2"><?php echo e(session('lineCount2')); ?></p>
                    <?php endif; ?>
                    <div class="py-2" x-data="{ open: false }">
                        <h2 class="font-bold mb-2 text-lg">Choose Line-2 Font</h2>
                        <span class="p-6 border border-main bg-dark w-full inline-block rounded-lg text-center font-semibold mb-3 uppercase" x-on:click="open = !open">Open / close</span>
                        <div class="grid grid-cols-2 gap-2 475px:grid-cols-1" x-show="open" x-cloak>
                            <?php $__currentLoopData = $fonts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fonty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="p-3 cursor-pointer rounded-lg text-center border text-lg capitalize <?php echo e($fonty); ?> <?php if($font2 == $fonty): ?> border-main <?php else: ?> border-white/10 <?php endif; ?>" wire:click="$set('font2', '<?php echo e($fonty); ?>')">
                                    <?php echo e($fonty); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="py-2">
                        <h2 class="font-bold mb-2 text-lg">Choose a colour</h2>
                        <div class="flex flex-wrap">
                            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div wire:click="$set('color2', '<?php echo e($item); ?>')" class="rounded-full m-2" style="<?php if($color2 == $item): ?> border: 2px <?php echo e($item); ?> solid; <?php endif; ?>">
                                    <span class="flex p-2 cursor-pointer rounded-full flex-col border border-white shadow-md" style="background-color: <?php echo e($item); ?>;"></span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if($line_count == 3): ?>
               <div class="p-6 bg-[#1E1E1E] rounded-lg mb-5">
                    <h2 class="font-bold text-lg">Line Three Text</h2>
                    <?php $__errorArgs = ['line3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 mb-2"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="text" wire:model.debounce.1000ms="line3" placeholder="Text Line Three" class="w-full mt-2 bg-dark rounded border focus:border-main focus:ring-4 focus:ring-main-light text-base outline-none text-gray-200 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out mb-3">
                    <?php if(session('lineCount3')): ?>
                        <p class="text-red-600 mb-2"><?php echo e(session('lineCount3')); ?></p>
                    <?php endif; ?>
                    <div class="py-2" x-data="{ open: false }">
                        <h2 class="font-bold mb-2 text-lg">Choose Line-3 Font</h2>
                        <span class="p-6 border border-main bg-dark w-full inline-block rounded-lg text-center font-semibold mb-3 uppercase" x-on:click="open = !open">Open / close</span>
                        <div class="grid grid-cols-2 gap-2 475px:grid-cols-1" x-show="open" x-cloak>
                            <?php $__currentLoopData = $fonts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fonty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="p-3 cursor-pointer rounded-lg text-center border text-lg capitalize <?php echo e($fonty); ?> <?php if($font3 == $fonty): ?> border-main <?php else: ?> border-white/10 <?php endif; ?>" wire:click="$set('font3', '<?php echo e($fonty); ?>')">
                                    <?php echo e($fonty); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="py-2">
                        <h2 class="font-bold mb-2 text-lg">Choose a colour</h2>
                        <div class="flex flex-wrap">
                            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div wire:click="$set('color3', '<?php echo e($item); ?>')" class="rounded-full m-2" style="<?php if($color3 == $item): ?> border: 2px <?php echo e($item); ?> solid; <?php endif; ?>">
                                    <span class="flex p-2 cursor-pointer rounded-full flex-col border border-white shadow-md" style="background-color: <?php echo e($item); ?>;"></span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
               </div>
            <?php endif; ?>

            <div class="py-2">
                <h2 class="font-bold mb-2 text-lg">Neon Strip Color When Light Off</h2>
                <div class="grid grid-cols-2 gap-3">
                    <div wire:click="$set('jacket', 'colored')" class="flex p-3 bg-dark cursor-pointer rounded-md flex-col mb-3 border <?php if($jacket == 'colored'): ?> border-main <?php else: ?> border-gray-800 <?php endif; ?>">
                        <p class="font-semibold mb-2">Similar Color as Light Color</p>
                        <span class="text-gray-500 text-sm">The tube will be colored when turned off.</span>
                    </div>
                    <div wire:click="$set('jacket', 'white')" class="flex p-3 bg-dark cursor-pointer rounded-md flex-col mb-3 border <?php if($jacket == 'white'): ?> border-main <?php else: ?> border-gray-800 <?php endif; ?>">
                        <p class="font-semibold mb-2">Milky White</p>
                        <span class="text-gray-500 text-sm">Your sign will be white when turned off.</span>
                    </div>
                </div>
            </div>

            <div class="py-2">
                <h2 class="font-bold text-lg mb-3">Backboard Style <span class="text-main">* <?php echo e($shape); ?></span></h2>
                <div class="py-3">
                    <select name="shape" id="shape" wire:model="shape" class="bg-dark flex items-center w-full justify-center p-3 cursor-pointer rounded-md flex-col border">
                        <?php $__currentLoopData = $shapes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->shape); ?>"><?php echo e($item->shape); ?> - $<?php echo e($item->price); ?></option>  
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </select>
                </div>
            </div>
            <div class="py-2">
                <h2 class="font-bold text-lg mb-1">Location <span class="text-main">* <?php echo e($location); ?></span></h2>
                <div class="py-3 grid grid-cols-2 gap-4">
                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div wire:click="$set('location', '<?php echo e($loc); ?>')" class="flex bg-dark mb-4 items-center justify-center p-3 cursor-pointer rounded-md flex-col border <?php if($location == $loc): ?> border-main <?php else: ?> border-gray-800 <?php endif; ?>">
                            <p class="font-semibold text-center"><?php echo e($loc); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="py-2">
                <h2 class="font-bold text-lg">Power Adaptor <span class="text-main">* <?php echo e($adaptor); ?></span></h2>
                <div class="mt-1">
                    <select wire:model="adaptor" class="w-full mt-2 bg-dark rounded border border-gray-800 focus:border-main focus:ring-4 focus:ring-main-light text-base outline-none text-gray-200 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out mb-3">
                        <?php $__currentLoopData = $adaptors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemAdapt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($loop->first): ?>
                                <option value="<?php echo e($itemAdapt); ?>" selected><?php echo e($itemAdapt); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($itemAdapt); ?>"><?php echo e($itemAdapt); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="py-2">
                <h2 class="font-bold text-lg">Remote and Dimmer <span class="text-main">* <?php echo e($remote); ?></span></h2>
                <p class="text-gray-500 text-sm">A remote and dimmer to control the light colour</p>
                <div class="py-3 w-full">
                    <select name="remote" id="remote" wire:model="remote" class="bg-dark flex items-center w-full justify-center p-3 cursor-pointer rounded-md flex-col border">
                        <?php $__currentLoopData = $remotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->type); ?>"><?php echo e($item->type); ?> - $<?php echo e($item->price); ?></option>  
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </select>
                </div>
            </div>
            <?php $__errorArgs = ['remote'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-600 mb-2"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="py-2">
                <h2 class="font-bold text-lg">Installation Kit <span class="text-main">* <?php echo e($kit); ?></span></h2>
                <div class="py-3 w-full">
                    <select name="kit" id="kit" wire:model="kit" class="bg-dark flex items-center w-full justify-center p-3 cursor-pointer rounded-md flex-col border">
                        <?php $__currentLoopData = $kits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?> - $<?php echo e($item->price); ?></option>  
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </select>
                </div>
            </div>
            <?php $__errorArgs = ['kit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-600 mb-2"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <input type="number" min="5" wire:model.debounce.500ms="phone" placeholder="Phone Number (shipping purpose)" class="w-full border-none bg-dark mt-2 rounded focus:border-main focus:ring-4 focus:ring-main text-base outline-none text-gray-300 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out mb-3">
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-600 mb-2"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <input type="text" wire:model.debounce.500ms="address" placeholder="Shipping Address" class="w-full border-none bg-dark mt-2 rounded focus:border-main focus:ring-4 focus:ring-main text-base outline-none text-gray-300 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out mb-3">
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-600 mb-2"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <input type="text" wire:model.debounce.500ms="email" placeholder="Email Address" class="w-full border-none bg-dark mt-2 rounded focus:border-main focus:ring-4 focus:ring-main text-base outline-none text-gray-300 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out mb-3">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-600 mb-2"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <button class="py-3 px-4 w-full bg-white rounded-md font-bold text-dark" wire:click="checkout" type="submit">Checkout</button>
            <div class="flex justify-between items-center w-full mt-2 py-3">
                <img src="<?php echo e(asset('assets/images/payment_cards.png')); ?>" width="190px" alt="Stripe Payment methods icon">
                <img src="<?php echo e(asset('assets/images/stripe_square_logo.png')); ?>" width="190px" alt="Powerd by stipe image">
            </div>
        </form>
    </div>
    <section class="max-w-[1366px] m-auto">
        <p class="p-6 col-span-2 border-l border-gray-400 bg-light text-white mb-6 leading-6">We're pleased to offer Stripe as our payment system, providing you with a secure and reliable way to make payments. With Stripe, your credit card information is kept safe and secure, as we don't store it on our servers. We only collect your email address for communication purposes, and we never share your personal information with third parties. Stripe's user-friendly interface allows for seamless payments, giving you peace of mind and a smooth payment experience. Thank you for choosing to shop with us!</p>
    </section>
    <section class="bg-light">
        <?php if (isset($component)) { $__componentOriginal7032ad33f7d2e5daad1fb1070e3383c1 = $component; } ?>
<?php $component = App\View\Components\Listing::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('listing'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Listing::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7032ad33f7d2e5daad1fb1070e3383c1)): ?>
<?php $component = $__componentOriginal7032ad33f7d2e5daad1fb1070e3383c1; ?>
<?php unset($__componentOriginal7032ad33f7d2e5daad1fb1070e3383c1); ?>
<?php endif; ?>
    </section>
    <section class="bg-dark">
        <?php if (isset($component)) { $__componentOriginalb172f205931d7b59a285aa900136a8cd = $component; } ?>
<?php $component = App\View\Components\FAQ::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('f-a-q'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FAQ::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb172f205931d7b59a285aa900136a8cd)): ?>
<?php $component = $__componentOriginalb172f205931d7b59a285aa900136a8cd; ?>
<?php unset($__componentOriginalb172f205931d7b59a285aa900136a8cd); ?>
<?php endif; ?>
    </section>
    <script>
        const color = document.getElementById('color');
        var output = document.getElementById('backDiv');

        const text = document.getElementById('main-text');
        const move = document.getElementById('move');

        const text1 = document.getElementById('text1');
        const text2 = document.getElementById('text2');

        output.style.backgroundColor = "#000000";

        var loadFile = function(event) {
          output.style.backgroundColor = "transparent";
          var myImageURL = URL.createObjectURL(event.target.files[0]).toString();
          console.log(event.target.files[0]);
          output.style.backgroundImage = `url(${myImageURL})`;
          document.cookie = `myimageurl=${myImageURL}`;
        
            //   output.onload = function() {
            //     var myURL = URL.revokeObjectURL(output.src)
            //     console.log(myURL)
            //   }
        };

        function change(){
            output.style.backgroundColor = color.value;
        }

        move.oninput = function() {
            text.style.transform = `translateY(${move.value}px)`;
        }
      </script>
</section><?php /**PATH E:\Laravel\vital_neon\resources\views/livewire/create-design.blade.php ENDPATH**/ ?>