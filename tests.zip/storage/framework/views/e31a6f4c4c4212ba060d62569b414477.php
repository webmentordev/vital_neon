<?php echo e($slot); ?>

<?php /**PATH E:\Laravel\vital_neon\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>