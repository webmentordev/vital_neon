<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => $__env->getContainer()->make(Illuminate\View\Factory::class)->make('mail::message'),'data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mail::message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
# Order Confirmation  
Dear <b>Customer</b>,  

We hope this email finds you well. I am writing to inform you that your order has been placed. We have assigned you the order id.   
# Paid: $<?php echo e($data[1]); ?>

Please keep this order id safe and secure, as it will be required every time you contact our support team. We understand the importance of protecting your privacy and security, and we assure you that your order id will be kept confidential and only used for the purposes of providing you with the best possible support.    

If you have any questions or concerns regarding your order, please do not hesitate to reach out to us at <b>contact@vitalneon.com</b> or <b>Whatsapp</b> Our support team will be happy to assist you with any inquiries you may have.  
Thank you for choosing our services and for entrusting us with your support needs. We look forward to continuing to serve you.
  
### OrderID:  
<?php echo e($data[0]); ?>


Best Regards,  
<b>VitalNeon Support</b>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH E:\Laravel\vital_neon\resources\views/emails/order-confirm.blade.php ENDPATH**/ ?>