[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH E:\Web Development\vital_neon\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>