[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH E:\Laravel\vital_neon\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>