<?php echo e($slot); ?>

<?php /**PATH E:\Web Development\vital_neon\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>