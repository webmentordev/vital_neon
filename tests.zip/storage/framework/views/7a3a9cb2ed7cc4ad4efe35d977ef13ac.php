
<?php $__env->startSection('content'); ?>
    <section class="w-full py-[80px]">
        <div class="grid grid-cols-2 text-white gap-6 max-w-[1360px] m-auto min-h-[800px] 575px:min-h-fit 890px:flex 890px:flex-col bg-light p-6 mb-6">
            <div class="bg-cover bg-center relative rounded-lg flex justify-center items-center 890px:min-h-[800px] h-full" id="backDiv">
                <span class="fixed bg-main rounded-lg p-3 bottom-3 z-10 right-3 text-gray-800 text-4xl font-semibold z-50"><span class="text-2xl">$</span>0</span>
                
                <div class=" p-3 rounded-lg absolute top-2 left-2">
                    <img src="https://api.iconify.design/mdi:lightbulb-on.svg?color=%23e4aa0c" width="35" alt="Sun Image">
                    <img src="https://api.iconify.design/mdi:lightbulb-on.svg?color=%23ffffff" width="35" alt="Moon Image">
                </div>

                <div class="absolute top-2 right-2">
                    <div class="flex items-center">
                        <div class="flex mr-1">
                            <div class="bg-gray-800 p-1 rounded-lg mb-1 cursor-pointer h-fit mr-1" wire:click="upSize">
                                <img src="https://api.iconify.design/material-symbols:add-rounded.svg?color=%23ffffff" width="30" alt="">
                            </div>
                            <div class="bg-gray-800 p-1 rounded-lg cursor-pointer h-fit" wire:click="downSize">
                                <img src="https://api.iconify.design/ic:outline-remove.svg?color=%23ffffff" width="30" alt="">
                            </div>
                        </div>
                        <div class="flex flex-col">
                            <div class="bg-gray-800 p-1 rounded-lg mb-1 cursor-pointer" wire:click="upHeight">
                                <img src="https://api.iconify.design/ic:outline-keyboard-arrow-up.svg?color=%23ffffff" width="30" alt="">
                            </div>
                            <div class="bg-gray-800 p-1 rounded-lg cursor-pointer" wire:click="downHeight">
                                <img src="https://api.iconify.design/ic:outline-keyboard-arrow-down.svg?color=%23ffffff" width="30" alt="">
                            </div>
                        </div>
                    </div>
                </div>

                <input type="range" id="move" name="move" min="-400" value="0" max="400" class="absolute rotate-90" style="right:-280px; width: 600px; height: 5px">
                
                <div class="flex flex-col" id="main-text">
                    <span class="text-white font-semibold" 
                    style="text-shadow:
                    #fff 0px 0px 5px,
                    #fff 0px 0px 10px,
                    #fff 0px 0px 20px,
                    #fff 0px 0px 30px,
                    #fff 0px 0px 40px,
                    #fff 0px 0px 55px,
                    #fff 0px 0px 75px; font-size: 45px;">Text Line 1</span>
                    
                    <span class="text-white font-semibold" 
                    style="text-shadow:
                        #fff 0px 0px 5px,
                        #fff 0px 0px 10px,
                        #fff 0px 0px 20px,
                        #fff 0px 0px 30px,
                        #fff 0px 0px 40px,
                        #fff 0px 0px 55px,
                        #fff 0px 0px 75px; font-size: 45px; margin-top: 20px">Text Line 2</span>
                    
                    <span class="text-white font-semibold" 
                    style="text-shadow:
                    #fff 0px 0px 5px,
                    #fff 0px 0px 10px,
                    #fff 0px 0px 20px,
                    #fff 0px 0px 30px,
                    #fff 0px 0px 40px,
                    #fff 0px 0px 55px,
                    #fff 0px 0px 75px; font-size: 45px; margin-top: 20px">Text Line 3</span>
                    
                </div>

                <div class="flex items-center justify-between absolute w-full bottom-0 p-3">
                    <input type="color" class="hidden" id="color" onchange="change()">
                    <label for="color" class="bg-white p-3 rounded-full"><img width="30" src="https://api.iconify.design/nimbus:color-palette.svg?color=%230d92f8" alt="Palet Icon"></label>
                    <div class="px-2">
                        <label for="photo" class="flex items-center"><span class="mr-2 text-white font-semibold 400px:hidden">Upload Your Own Image</span><img src="https://api.iconify.design/line-md:uploading-loop.svg?color=%23ffffff" width="40" alt="Upload"></label>
                        <input type="file" id="photo" accept="image/*" onchange="loadFile(event)" class="hidden">
                    </div>
                </div>
            </div>
            <form wire:submit.prevent="checkout" method="POST" class="text-sm max-h-[900px] overflow-y-scroll 850px:max-h-full px-6 py-6 850px:px-0 850px:overflow-y-hidden">
                <div class="flex items-center justify-between 490px:flex-col">
                    <h1 class="text-main font-bold text-3xl mb-3">Design Your Neon</h1>
                    <div class="flex items-center">
                        <img wire:click="$set('alignment', 'items-center')" src="https://api.iconify.design/material-symbols:format-align-center.svg?color=%23FFFFFF" class="p-2 rounded-lg bg-dark mr-2" alt="Alignment Icon" width="50">
                        <img wire:click="$set('alignment', 'items-start')" src="https://api.iconify.design/ic:baseline-format-align-left.svg?color=%23FFFFFF" class="p-2 rounded-lg bg-dark mr-2" alt="Alignment Icon" width="50">
                        <img wire:click="$set('alignment', 'items-end')" src="https://api.iconify.design/ic:baseline-format-align-right.svg?color=%23FFFFFF" class="p-2 rounded-lg bg-dark" alt="Alignment Icon" width="50">
                    </div>
                </div>
                <?php if(session('failed')): ?>
                    <p class="text-white p-6 fixed bottom-2 left-2 z-20 rounded-lg bg-red-700 mb-3 border-red-600 border"><?php echo e(session('failed')); ?></p>
                <?php endif; ?>
                <div class="py-2">
                    <h2 class="font-bold text-lg">Text Line & Size Options</h2>
                    <?php $__errorArgs = ['line_check'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 mb-2"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="mt-1">
                        <select wire:model="Select" class="w-full mt-2 bg-dark rounded border focus:border-main focus:ring-4 focus:ring-main-light text-base outline-none text-gray-300 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out mb-3">
                            <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($loop->first): ?>
                                    <option value="<?php echo e($line->name); ?>" selected><?php echo e($line->name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($line->name); ?>"><?php echo e($line->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                
                
                <div class="p-6 bg-[#1E1E1E] rounded-lg mb-5">
                    <h2 class="font-bold text-lg">Line One Text</h2>
                    <?php $__errorArgs = ['line1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 mb-2"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="text" wire:model.debounce.1000ms="line1" placeholder="Text Line One" class="w-full mt-2 bg-dark rounded border focus:border-main focus:ring-4 focus:ring-main-light text-base outline-none text-gray-200 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out mb-3">
                    <?php if(session('lineCount1')): ?>
                        <p class="text-red-600 mb-2"><?php echo e(session('lineCount1')); ?></p>
                    <?php endif; ?>
                    <div class="py-2" x-data="{ open: false }">
                        <h2 class="font-bold mb-2 text-lg">Choose Line-1 Font</h2>
                        <span class="p-6 border-white bg-dark w-full" x-on:click="open = !open">Open now</span>
                        <div class="grid grid-cols-2 gap-2 475px:grid-cols-1" x-show="open">
                            <?php $__currentLoopData = $fonts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fonty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="p-3 cursor-pointer rounded-lg text-center border text-lg capitalize">
                                    <?php echo e($fonty); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="py-2">
                        <h2 class="font-bold mb-2 text-lg">Choose a colour</h2>
                        <div class="flex flex-wrap">
                            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="rounded-full m-2">
                                    <span class="flex p-2 cursor-pointer rounded-full flex-col border border-white shadow-md" style="background-color: <?php echo e($item); ?>;"></span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                

                
                    <div class="p-6 bg-[#1E1E1E] rounded-lg mb-5">
                        <h2 class="font-bold text-lg">Line Two Text</h2>
                        <?php $__errorArgs = ['line2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 mb-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <input type="text" name="line2" placeholder="Text Line Two" class="w-full mt-2 bg-dark rounded border focus:border-main focus:ring-4 focus:ring-main-light text-base outline-none text-gray-200 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out mb-3">
                        <?php if(session('lineCount2')): ?>
                            <p class="text-red-600 mb-2"><?php echo e(session('lineCount2')); ?></p>
                        <?php endif; ?>
                        <div class="py-2">
                            <h2 class="font-bold mb-2 text-lg">Choose Line-2 Font</h2>
                            <div class="grid grid-cols-2 gap-2 475px:grid-cols-1">
                                <?php $__currentLoopData = $fonts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fonty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="p-3 cursor-pointer rounded-lg text-center border text-lg capitalize">
                                        <?php echo e($fonty); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="py-2">
                            <h2 class="font-bold mb-2 text-lg">Choose a colour</h2>
                            <div class="flex flex-wrap">
                                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="rounded-full m-2">
                                        <span class="flex p-2 cursor-pointer rounded-full flex-col border border-white shadow-md" style="background-color: <?php echo e($item); ?>;"></span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>

                
                <div class="p-6 bg-[#1E1E1E] rounded-lg mb-5">
                    <h2 class="font-bold text-lg">Line Three Text</h2>
                    <?php $__errorArgs = ['line3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 mb-2"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="text" name="line3" placeholder="Text Line Three" class="w-full mt-2 bg-dark rounded border focus:border-main focus:ring-4 focus:ring-main-light text-base outline-none text-gray-200 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out mb-3">
                    <?php if(session('lineCount3')): ?>
                        <p class="text-red-600 mb-2"><?php echo e(session('lineCount3')); ?></p>
                    <?php endif; ?>
                    <div class="py-2">
                        <h2 class="font-bold mb-2 text-lg">Choose Line-3 Font</h2>
                        <div class="grid grid-cols-2 gap-2 475px:grid-cols-1">
                            <?php $__currentLoopData = $fonts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fonty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="p-3 cursor-pointer rounded-lg text-center border text-lg capitalize <?php echo e($fonty); ?>">
                                    <?php echo e($fonty); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="py-2">
                        <h2 class="font-bold mb-2 text-lg">Choose a colour</h2>
                        <div class="flex flex-wrap">
                            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="rounded-full m-2">
                                    <span class="flex p-2 cursor-pointer rounded-full flex-col border border-white shadow-md" style="background-color: <?php echo e($item); ?>;"></span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                
                <div class="py-2">
                    <h2 class="font-bold mb-2 text-lg">Neon Strip Color When Light Off</h2>
                    <div  class="flex p-3 bg-dark cursor-pointer rounded-md flex-col mb-3 border border-main">
                        <p class="font-semibold mb-2">Similar Color as Light Color</p>
                        <span class="text-gray-500 text-sm">The tube will be colored when turned off.</span>
                    </div>
                    <div  class="flex p-3 bg-dark cursor-pointer rounded-md flex-col mb-3 border border-main">
                        <p class="font-semibold mb-2">Milky White</p>
                        <span class="text-gray-500 text-sm">Your sign will be white when turned off.</span>
                    </div>
                </div>

                <div class="py-2">
                    <h2 class="font-bold text-lg mb-3">Backboard Style</h2>
                    <div class="py-3">
                        <?php $__currentLoopData = $shapes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex bg-dark mb-4 p-3 cursor-pointer rounded-md flex-col border border-main">
                                <p class="font-semibold mb-2"><?php echo e($item->shape); ?> ($<?php echo e($item->price); ?>)</p>
                                <span class="text-gray-500 text-sm"><?php echo e($item->description); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="py-2">
                    <h2 class="font-bold text-lg mb-3">Location</h2>
                    <div class="py-3 grid grid-cols-2 gap-4">
                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div wire:click="$set('location', '<?php echo e($loc); ?>')" class="flex bg-dark mb-4 items-center justify-center p-3 cursor-pointer rounded-md flex-col border border-main">
                                <p class="font-semibold text-center"><?php echo e($loc); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="py-2">
                    <h2 class="font-bold text-lg">Power Adaptor</h2>
                    <div class="mt-1">
                        <select wire:model="adaptor" class="w-full mt-2 bg-dark rounded border border-gray-800 focus:border-main focus:ring-4 focus:ring-main-light text-base outline-none text-gray-200 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out mb-3">
                            <?php $__currentLoopData = $adaptors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemAdapt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($loop->first): ?>
                                    <option value="<?php echo e($itemAdapt); ?>" selected><?php echo e($itemAdapt); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($itemAdapt); ?>"><?php echo e($itemAdapt); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="py-2">
                    <h2 class="font-bold text-lg">Remote and Dimmer</h2>
                    <p class="text-gray-500 text-sm">A remote and dimmer is included free with every sign! (Except for Multicolor Neon Signs, which are controlled by the APP)</p>
                    <div class="py-3 w-full">
                        <select name="remote" id="remote" wire:model="remote" class="bg-dark flex items-center w-full justify-center p-3 cursor-pointer rounded-md flex-col border">
                            <?php $__currentLoopData = $remotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->type); ?>"><?php echo e($item->type); ?> - $<?php echo e($item->price); ?></option>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </select>
                    </div>
                </div>
                <?php $__errorArgs = ['remote'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 mb-2"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="py-2">
                    <h2 class="font-bold text-lg">Installation Kit</h2>
                    <div class="py-3 w-full">
                        <select name="kit" id="kit" wire:model="kit" class="bg-dark flex items-center w-full justify-center p-3 cursor-pointer rounded-md flex-col border">
                            <?php $__currentLoopData = $kits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?> - $<?php echo e($item->price); ?></option>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </select>
                    </div>
                </div>
                <?php $__errorArgs = ['kit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 mb-2"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <input type="number" min="5" name="phone" placeholder="Phone Number (shipping purpose)" class="w-full border-none bg-dark mt-2 rounded focus:border-main focus:ring-4 focus:ring-main text-base outline-none text-gray-300 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out mb-3">
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 mb-2"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <input type="text" name="email" placeholder="Email Address" class="w-full border-none bg-dark mt-2 rounded focus:border-main focus:ring-4 focus:ring-main text-base outline-none text-gray-300 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out mb-3">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 mb-2"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <button class="submit-btn" type="submit"><span class="mr-2 text-xl">Checkout</span> <img src="<?php echo e(asset('assets/images/stripe_small.png')); ?>" width="50" alt="Stripe Logo"></button>

            </form>
            <p class="p-6 col-span-2 border-l border-gray-400 bg-light text-white mb-6 leading-6">We're pleased to offer Stripe as our payment system, providing you with a secure and reliable way to make payments. With Stripe, your credit card information is kept safe and secure, as we don't store it on our servers. We only collect your email address for communication purposes, and we never share your personal information with third parties. Stripe's user-friendly interface allows for seamless payments, giving you peace of mind and a smooth payment experience. Thank you for choosing to shop with us!</p>
        </div>
        <section class="bg-light">
            <?php if (isset($component)) { $__componentOriginal7032ad33f7d2e5daad1fb1070e3383c1 = $component; } ?>
<?php $component = App\View\Components\Listing::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('listing'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Listing::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7032ad33f7d2e5daad1fb1070e3383c1)): ?>
<?php $component = $__componentOriginal7032ad33f7d2e5daad1fb1070e3383c1; ?>
<?php unset($__componentOriginal7032ad33f7d2e5daad1fb1070e3383c1); ?>
<?php endif; ?>
        </section>
        <section class="bg-dark">
            <?php if (isset($component)) { $__componentOriginalb172f205931d7b59a285aa900136a8cd = $component; } ?>
<?php $component = App\View\Components\FAQ::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('f-a-q'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FAQ::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb172f205931d7b59a285aa900136a8cd)): ?>
<?php $component = $__componentOriginalb172f205931d7b59a285aa900136a8cd; ?>
<?php unset($__componentOriginalb172f205931d7b59a285aa900136a8cd); ?>
<?php endif; ?>
        </section>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Web Development\vital_neon\resources\views/create-design.blade.php ENDPATH**/ ?>