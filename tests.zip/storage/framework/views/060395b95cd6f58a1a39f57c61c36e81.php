<div class="h-[600px] w-[600px] relative" id="backDiv">
    <div class="flex items-center justify-between absolute w-full bottom-0 p-3">
        <input type="color" class="hidden" id="color" onchange="change()">
        <label for="color" class="bg-white p-3 rounded-full"><img width="30" src="https://api.iconify.design/nimbus:color-palette.svg?color=%230d92f8" alt="Palet Icon"></label>
        <div class="px-2">
            <label for="photo" class="flex items-center"><span class="mr-2 text-white font-semibold 400px:hidden">Upload Your Own Image</span><img src="https://api.iconify.design/line-md:uploading-loop.svg?color=%23ffffff" width="40" alt="Upload"></label>
            <input type="file" id="photo" accept="image/*" onchange="loadFile(event)" class="hidden">
        </div>
    </div>
</div>
<script>
    const color = document.getElementById('color');
    var output = document.getElementById('backDiv');

    output.style.backgroundColor = "#000000";

    var loadFile = function(event) {
      output.style.backgroundColor = "transparent";
      output.style.backgroundImage = `url(${URL.createObjectURL(event.target.files[0]).toString()})`;
      output.onload = function() {
        var myURL = URL.revokeObjectURL(output.src)
        console.log(myURL)
      }
    };
  </script><?php /**PATH E:\Web Development\vital_neon\resources\views/components/draw.blade.php ENDPATH**/ ?>